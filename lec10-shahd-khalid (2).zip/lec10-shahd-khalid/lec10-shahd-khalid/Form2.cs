﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lec10_shahd_khalid
{
    public partial class Form2 : Form
    {
       
        public Form2()
        {
            InitializeComponent();
        }

        bool ischoceimage = false;
        private void Form2_Load(object sender, EventArgs e)
        {
            
        }
        public static student[] s = new student[100];
        public static int count = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (count < 100)
            {
                if (ischoceimage)
                {
                    s[count] = new student();
                    s[count].SetNumber(Convert.ToInt32(numericUpDown1.Value));
                    s[count].SetName(textBox1.Text);
                    s[count].SetBirthdate(dateTimePicker1.Text);
                    s[count].SetImgPath(openFileDialog1.FileName);
                    count++;
                    ischoceimage = false;
                    pictureBox1.Image = null;
                    numericUpDown1.Value = 0;
                    textBox1.Text = "";
                    MessageBox.Show("تم إضافة الطالب بنجاح", "نجـاح");
                }
                else
                    MessageBox.Show("الرجـاء اختيار صورة الطالب", "تحـذير");
            }
            else
                MessageBox.Show("الحد المسموح به مائة طالب فقط", "تحـذير");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "img(*.jpg)|*.jpg|(img*.bmp;*.png)|*.bmp;*.png";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                ischoceimage = true;
            }
        }
    }
}
