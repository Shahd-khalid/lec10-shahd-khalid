﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lec10_shahd_khalid
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        void loadstudentdata()
        {
            for (int i = 0; i < Form2.count; i++)
            {
                listBox1.Items.Add(Form2.s[i].Getnumber().ToString());
                listBox2.Items.Add(Form2.s[i].GetName().ToString());
                listBox3.Items.Add(Form2.s[i].GetBirthdate().ToString());
                pictureBox1.Image = Image.FromFile(Form2.s[i].GetImgPath());
            }
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            loadstudentdata();

            listBox1.SelectedIndexChanged += findselectedindexlist;
            listBox2.SelectedIndexChanged += findselectedindexlist;
            listBox3.SelectedIndexChanged += findselectedindexlist;
        }
        public static int index = -1;
        void findselectedindexlist(object sender, EventArgs e)
        {
            if (((ListBox)sender).SelectedIndex != -1)
            {
                index = listBox3.SelectedIndex = listBox2.SelectedIndex = listBox1.SelectedIndex
                    = ((ListBox)sender).SelectedIndex;

                pictureBox1.Image = Image.FromFile(Form2.s[index].GetImgPath());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedItems != null)
            {
                listBox1.Items.Remove(listBox1.SelectedItems);
                listBox2.Items.Remove(listBox2.SelectedItems);
                listBox3.Items.Remove(listBox3.SelectedItems);

                for (int i = index; i < Form2.count; i++)
                {
                    Form2.s[i] = Form2.s[i + 1];
                    Form2.count--;
                    if (Form2.count >= 1)
                    {
                        // pictureBox1.Image = Image.FromFile(Form2.s[Form2.count - 1].GetImgPath());
                        pictureBox1.Image = Image.FromFile(Form2.s[0].GetImgPath());
                        listBox1.SelectedIndex = listBox2.SelectedIndex = listBox3.SelectedIndex = 0;
                    }
                    else
                        pictureBox1.Image = null;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            loadstudentdata();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (listBox1.SelectedItems != null)
            {
                Form4 f = new Form4();
                f.ShowDialog();
                listBox1.Items[index] = Form2.s[index].Getnumber();
                listBox2.Items[index] = Form2.s[index].GetName();
                listBox3.Items[index] = Form2.s[index].GetBirthdate();
                pictureBox1.Image = Image.FromFile(Form2.s[index].GetImgPath());

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
